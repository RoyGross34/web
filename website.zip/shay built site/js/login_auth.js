
const firebaseConfig = {
    apiKey: "AIzaSyAyr4SdYvPA8ndMpuxZBKosXlUUrPg3kak",
    authDomain: "lifewatch-5884c.firebaseapp.com",
    databaseURL: "https://lifewatch-5884c-default-rtdb.europe-west1.firebasedatabase.app",
    projectId: "lifewatch-5884c",
    storageBucket: "lifewatch-5884c.appspot.com",
    messagingSenderId: "1037406836995",
    appId: "1:1037406836995:web:07637be2c62b530c36f136",
    measurementId: "G-X3KCH5YCBL"
};

// Initialize Firebase
// Initialize Firebase
firebase.initializeApp(firebaseConfig);
const auth = firebase.auth();
const database = firebase.database();







//login page


document.getElementById("login").addEventListener("submit", function (event) {
    // Prevent the default form submission behavior
    event.preventDefault();
    // Get the email, password
    var email = document.getElementById("lo_email").value;
    var password = document.getElementById("lo_password").value;
  
    firebase
      .auth()
      .signInWithEmailAndPassword(email, password)
      .then((response) => response.user.getIdToken())
      .then((idToken) => {
        console.log("Firebase ID token:", idToken);
        localStorage.setItem("firebase_id_token", idToken);
        console.log("Token saved to local storage!");
      })
      .then(() => {
        window.location = "home.html";
      })
      .catch((error) => {
        console.log(error);
        alert(error.message);
      });
  });
