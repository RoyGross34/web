// // Import the functions you need from the SDKs you need
// import { initializeApp } from "https://www.gstatic.com/firebasejs/9.17.1/firebase-app.js";
// import { getAnalytics } from "https://www.gstatic.com/firebasejs/9.17.1/firebase-analytics.js";
// TODO: Add SDKs for Firebase products that you want to use
// https://firebase.google.com/docs/web/setup#available-libraries

// Your web app's Firebase configuration
// For Firebase JS SDK v7.20.0 and later, measurementId is optional
const firebaseConfig = {
    apiKey: "AIzaSyAyr4SdYvPA8ndMpuxZBKosXlUUrPg3kak",
    authDomain: "lifewatch-5884c.firebaseapp.com",
    databaseURL: "https://lifewatch-5884c-default-rtdb.europe-west1.firebasedatabase.app",
    projectId: "lifewatch-5884c",
    storageBucket: "lifewatch-5884c.appspot.com",
    messagingSenderId: "1037406836995",
    appId: "1:1037406836995:web:07637be2c62b530c36f136",
    measurementId: "G-X3KCH5YCBL"
};

// Initialize Firebase
// Initialize Firebase
firebase.initializeApp(firebaseConfig);
const auth = firebase.auth();
const database = firebase.database();



document.getElementById('sing_up').addEventListener("submit", function (event) {
    console.log("hey");
    event.preventDefault();
    var su_username = document.getElementById("su-username").value;
    var su_email = document.getElementById("su_email").value;
    var su_psw = document.getElementById("su-psw").value;
    var su_psw_repeat = document.getElementById("psw-repeat").value;

    // email validation
    if (!/^\w+([\.-]?\w+)@\w+([\.-]?\w+)(\.\w{2,3})+$/.test(su_email)) {
        alert("Invalid email address");
        return;
    }
    // password validation
    if (su_psw.length < 8) {
        alert("Password must be at least 8 characters");
        return;
    }
    if (su_psw != su_psw_repeat) {
        alert("Password does not match");
        return;

    }

    // Create a new user with the provided email and password
    firebase
        .auth()
        .createUserWithEmailAndPassword(su_email, su_psw)
        .then((userCredential) => {
            // Sign up successful
            // Get the user's UID
            var user = userCredential.user;
            console.log(user.uid);
            // call a function to write the user's data to the database
            writeToRTDB(user.uid, su_email, su_username);
            // redirect the user to a new page
            window.location.href = "home.html";
        })
        .catch((error) => {
            // Handle sign up errors
            console.log(error);
            alert(error.message);
        });




});

// function to write data to RTDB
function writeToRTDB(userId, email, company, address) {
    firebase
      .database()
      .ref("users/" + userId)
      .set({
        email: su_email,
        username:su_username,

      });
  }



